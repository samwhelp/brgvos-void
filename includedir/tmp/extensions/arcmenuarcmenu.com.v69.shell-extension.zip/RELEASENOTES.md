<b><span size="large">v67.2</span></b>

- Add new menu layout "Zest".
- Fix power menu button active state bug.
- Ensure active menu item is cleared when menu is closed.

<b><span size="large">v67.1</span></b>

- Add GNOME 49 Support.
- Add hotkey option to toggle overriding the GNOME Overview hotkey when using 'Super' hotkeys for ArcMenu.
- Fix disposed menu item error when opening pinned apps context menu.
- Fix pan action scroll bug causing pan to function when started outside of the scrollview.

<b><span size="large">v67.0</span></b>

- Add support for multiple hotkeys for ArcMenu and Standalone Runner.
- Settings: Increase the maximum value of width options for the menu size.
- Update Notifier: only show donation option on major releases.
- Fix bug causing error logs to appear when activating search results with enter key.
- Fix rare bug causing empty categories if duplicate desktop files contained within the same category.